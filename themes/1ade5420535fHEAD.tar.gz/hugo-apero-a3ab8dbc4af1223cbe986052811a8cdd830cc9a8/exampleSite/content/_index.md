---
title: "Hugo Apéro"
subtitle: "A Hugo theme you'll want to hang out with"
description: "Sit down, relax, and get to know Hugo Apéro. Built on top of Blogophonic, we wanted to create a polished Hugo theme with the right features for a true personal website. We set out to create a theme that is a pleasure to learn, and one that helps others get to know you better. It is more than a blog, with flexible custom layouts that help you introduce yourself online."
images:
  - img/revoir.jpg
image_left: true
text_align_left: false
show_social_links: true # specify social accounts in site config
show_action_link: true
action_link: /about
action_label: "Read More &rarr;"
action_type: text # text, button
type: home
---

** index doesn't contain a body, just front matter above.
See index.html in the layouts folder **
